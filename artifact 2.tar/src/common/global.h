#ifndef GLOBAL_H
#define GLOBAL_H

// Global variable declaration
extern int global_variable;

// Function declarations
int get_global_variable();
void set_global_variable(int value);

#endif // GLOBAL_H
