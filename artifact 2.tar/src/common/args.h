#ifndef ARGS_H
#define ARGS_H

// Function declarations
int initialize_args(int argc, char *argv[]);
void finalize_args();

#endif // ARGS_H
