# Osx Image

## Travis Input

```yaml
osx_image: xcode12.4
```

### Transformed Github Action

```yaml
- uses: maxim-lobanov/setup-xcode@v1
  with:
    xcode-version: '12.3'
```
