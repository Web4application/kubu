# Rabbitmq

## Travis Input

```yaml
services:
  - rabbitmq
```

## Transformed Github Action

```yaml
services: 
  rabbitmq:
    image: rabbitmq
```

### Unsupported Options

- None
