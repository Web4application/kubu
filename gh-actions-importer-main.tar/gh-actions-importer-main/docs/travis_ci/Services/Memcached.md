# Memcached

## Travis Input

```yaml
services:
  - memcached
```

## Transformed Github Action

```yaml
services: 
  memcached:
    image: memcached
```

### Unsupported Options

- None
