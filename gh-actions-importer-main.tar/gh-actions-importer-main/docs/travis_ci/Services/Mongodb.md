# Mongodb

## Travis Input

```yaml
services:
  - mongodb
```

## Transformed Github Action

```yaml
services: 
  mongodb:
    image: mongo
```

### Unsupported Options

- None
