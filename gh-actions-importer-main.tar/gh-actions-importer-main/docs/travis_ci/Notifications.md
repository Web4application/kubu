# Notifications

- [Notifications/Irc.md](Irc)
- [Notifications/Pushover.md](Pushover)
- [Notifications/Slack.md](Slack)
- [Notifications/Webhooks.md](Webhooks)

Any notifications not listed above will not be mapped to an action.

## Unsupported

- campfire
- email
- flowdock
- hipchat

## Unsupported Properties

- sequence of booleans
