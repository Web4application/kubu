# Go

## Travis Input

```yaml
go: 1.11.x
```

## Transformed Github Action

```yaml
- uses: actions/setup-go@v3
  with:
    go-version: 1.11.x
```
