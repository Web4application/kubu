# Python

## Travis Input

```yaml
python: 7
```

## Transformed Github Action

```yaml
- uses: actions/setup-python@v2
  with:
    python-version: '2.7'
```
