# Scala

## Travis Input

```yaml
scala:
  - 2.9.3
  - 2.10.6
  - 2.11.11
```

## Transformed Github Action

```yaml
- uses: olafurpg/setup-scala@v14
```

## Unsupported Options

- scala version
