# Smalltalk

## Travis Input

```yaml
smalltalk:
  - Squeak-trunk
```

## Transformed Github Action

```yaml
- uses: hpi-swa/setup-smalltalkCI@v1
  with:
    smalltalk-image: Squeak64-trunk
```
