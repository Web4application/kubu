# Julia

## Travis Input

```yaml
julia: 1
```

## Transformed Github Action

```yaml
- uses: julia-actions/setup-julia@v1.9.0
  with:
    version: '2.7'
```
