# Dart

## Travis Input

```yaml
dart:
- stable
```

## Transformed Github Action

```yaml
  uses: dart-lang/setup-dart@v1.3
  with:
    sdk: stable
```
