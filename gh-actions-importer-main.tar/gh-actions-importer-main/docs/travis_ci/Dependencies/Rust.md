# Rust

## Travis Input

```yaml
rust: nightly
```

## Transformed Github Action

```yaml
- uses: actions-rs/toolchain@v1.0.6
  with:
    toolchain: '2.7'
```
