# Haxe

## Travis Input

```yaml
haxe:
  - "3.2.1"
```

## Transformed Github Action

```yaml
- uses: krdlab/setup-haxe@v1.4.0
  with:
    haxe-version: '3.2.1'
```
