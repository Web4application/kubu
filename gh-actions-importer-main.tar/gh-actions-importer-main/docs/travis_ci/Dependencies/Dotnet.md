# Dotnet

## Travis Input

```yaml
dotnet: 2.1.502
```

## Transformed Github Action

```yaml
- uses: actions/setup-dotnet@v3.0.3
  with:
    dotnet-version: '3.1.x'
```
