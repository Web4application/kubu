# [CircleCI Ruby](https://circleci.com/developer/orbs/orb/circleci/ruby)

| CircleCI                                                            | GitHub                                        |
| :------------------------------------------------------------------ | :-------------------------------------------- |
| [Default](Default.md)                                               | container                                     |
| [Install](Install.md)                                               | ruby/setup-ruby@v1.138.0                            |
| [InstallDeps](InstallDeps.md)                                       | run, ruby/setup-ruby@v1.138.0                       |
| [RspecTest](RspecTest.md)                                           | run                                           |
| [RubocopCheck](RubocopCheck.md)                                     | run                                           |

## Unsupported

- None
