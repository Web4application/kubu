# [CircleCI BrowserTools](https://circleci.com/developer/orbs/orb/circleci/browser-tools)

## Indeterminate behavior on self-hosted runners

- install-browser-tools
- install-chrome
- install-chromedriver
- install-firefox
- install-geckodriver
