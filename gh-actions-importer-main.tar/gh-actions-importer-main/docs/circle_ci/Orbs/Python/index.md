# [CircleCI Python](https://circleci.com/developer/orbs/orb/circleci/python)

| CircleCI                                                            | GitHub                                              |
| :------------------------------------------------------------------ | :-------------------------------------------------- |
| [Default](Default.md)                                               | container                                           |
| [Dist](Dist.md)                                                     | run                                                 |
| [InstallPackages](InstallPackages.md)                               | run, actions/cache@v2                               |
| [Test](Test.md)                                                     | run, actions/cache@v2, actions/upload-artifact@v2   |

## Indeterminate behavior on self-hosted runners

- dist

## Unsupported

- None
