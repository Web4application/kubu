# Stage Success

## Bamboo input

```json
  {
   "stage" : "build",
   "branch": "branch_PAN-GIT-JOB1-6"
  }
```

## Transformed Github Action

```yaml
on:
 workflow_dispatch:
```

## Unsupported Options

- None
