# Environment Success

## Bamboo input

```json
  {
    "environment" : "QA"
  }
```

## Transformed Github Action

```yaml
on:
 workflow_dispatch:
```

## Unsupported Options

- None
