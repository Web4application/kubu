# Build Success

## Bamboo input

```json
  {
    "expression": "0 0 1 * * 1-7"
  }
```

## Transformed Github Action

```yaml
on:
 workflow_dispatch:
```

## Unsupported Options

- None
