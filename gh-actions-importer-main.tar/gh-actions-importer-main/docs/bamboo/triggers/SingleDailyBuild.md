# Single daily build

This option is unsupported. While it is possible to configure the trigger, the extracted YAML does not contain the configuration information and returns the following

```yaml
triggers:
# Trigger type TriggerProperties{name='Single daily build', description='', conditions=[], enabled=true} is not supported yet
```
